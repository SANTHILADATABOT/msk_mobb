<?php
//Allow Headers
include("../../includes/dbConnect.php");
include("../../includes/common_function.php");
$image_size=$_FILES["file"]["size"];
$random_sc = date('dmyhis');
$random_no=rand(00000,99999);
$new_name = $random_no.$random_sc."."."jpg";
move_uploaded_file($_FILES["file"]["tmp_name"],$_SERVER['DOCUMENT_ROOT']."/royal_furniture_mobapp/img/customer_satisfaction/".$new_name);
echo $new_name;	
?>