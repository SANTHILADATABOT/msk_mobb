
<?php 
$personal_details='Personal Details';
$family_no='Family No'; 
$mohalla_no='Mohalla No';
$finding='Fact Finding Formssss';
$aadharno="Aadhar No";
?>
 