<?php

date_default_timezone_set('Asia/Kolkata');
header('Access-Control-Allow-Origin: *'); 
include("dbConnect.php");
?>


<?php 
if($_GET['action']=="volunteer_login")
{
  $mobile = $_GET['mobile'];
  $otp = $_GET['otp'];
// / echo "SELECT * FROM volunteer_otp WHERE mobile_number = '".$mobile."' AND otp = '".$otp."' ";
  $statement = $pdo_conn->prepare("SELECT * FROM volunteer_otp WHERE mobile_number = '".$mobile."' AND otp = '".$otp."' ");
  $statement->execute();
  $check = $statement->fetch();
  $count =$statement->rowCount();
  $fetched_otp = $check['otp'];
  $country_id = $check['country_id'];
  $state_id = $check['state_id'];
  $district_id = $check['district_id'];
 $user_id=$check['user_id'];
  $city_id = $check['city_id'];
  $area_id = $check['area_id'];
 $otp_id = $check['area_id'];
  if($count>0)
  {
	  echo  $country_id."@@".$state_id."@@".$district_id."@@".$city_id."@@".$area_id."@@".$otp_id."@@".$user_id;
  }
  else
  {
	  echo "0";
  }
}
?>
